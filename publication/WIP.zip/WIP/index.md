---
title: "Production Network, Endogenous Misallocation and the Gain from International Trade"
authors: 
- admin
date: "2023-97-07T00:00:00Z"
doi: ""

# Schedule page publish date (NOT publication's date).
#publishDate: "2022-12-01T00:00:00Z"

# Publication type.
# Legend: 0 = Uncategorized; 1 = Conference paper; 2 = Journal article;
# 3 = Preprint / Working Paper; 4 = Report; 5 = Book; 6 = Book section;
# 7 = Thesis; 8 = Patent
publication_types: ["0"]

# Publication name and optional abbreviated publication name.
#publication: "NBER Working Paper"
publication_short: ""

abstract: This paper theoretically examines new sources of trade gains arising from the interaction of (i) IO network and (ii) pro-competitive effects. To this end, we develop a general equilibrium model and derive an endogenous markup under oligopolistic competition with an IO network. Our markup has an intuitive closed-form function and nests the markup of Atkeson and Burstein (2008) as a special case. We use this model to revisit the problem considered by Edmond et al. (2015). We find that the IO network amplifies the gains associated with the reduction in misallocation and that the gains from trade are more than twice as large as in the absence of the IO network. Furthermore, we find that trade gains are even larger under the assumption of complementarity of intermediate goods.

# Summary. An optional shortened abstract.
summary: Presentated in @ Washu and @ Yale

tags:
#- Source Themes
featured: false

links:
url_pdf: ''
url_code: ''
url_dataset: ''
url_poster: ''
url_project: ''
url_slides: ''
url_source: ''
url_video: ''

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder. 
image:
  caption: 'Image credit: [**Unsplash**](https://unsplash.com/photos/s9CC2SKySJM)'
  focal_point: ""
  preview_only: false

# Associated Projects (optional).
#   Associate this publication with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `internal-project` references `content/project/internal-project/index.md`.
#   Otherwise, set `projects: []`.
#projects:


# Slides (optional).
#   Associate this publication with Markdown slides.
#   Simply enter your slide deck's filename without extension.
#   E.g. `slides: "example"` references `content/slides/example/index.md`.
#   Otherwise, set `slides: ""`.
slides: ''
---


